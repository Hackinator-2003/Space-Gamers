﻿############################################### CREATION DE LA CLASSE SECTION #######################################################

#Création de la classe Section
class Section():
    """
    Classe créant les sections du menu
    """

################################# CREATION DE LA FONCTION D'INITIALISATION DE LA CLASSE SECTION AVEC SES ATTRIBUTS ##################################

    #Initialisation de la classe Section et de ses attributs
    def __init__(self,text,action,description="",color=(100,100,100),hold_color=(200,200,200)):
        self.text = text
        self.action = action
        self.color = color
        self.description = description
        self.hold_color = hold_color
        self.parent = None

#######################################################################################################################################################

#######################################################################################################################################################
