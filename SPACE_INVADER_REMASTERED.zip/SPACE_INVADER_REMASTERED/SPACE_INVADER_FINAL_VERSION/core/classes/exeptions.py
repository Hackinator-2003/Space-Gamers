
#Création de deux exceptions utilisées dans la classe Game_Over pour revenir au menu principal ou rejouer

class ReplayEx(Exception):
    """
    Replay ask and raised
    """
    pass

class MenuEx(Exception):
    """
    Menu ask to show
    """
    pass
