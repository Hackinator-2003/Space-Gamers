﻿################################################ IMPORTATIONS DES MODULES NECESSAIRES ################################################

import pygame
from core.GUI import*

####################################################################################################################################

############################################### CREATION DE LA CLASSE PLAYER #######################################################

#Création de la classe Player
class Player():
    """
    La classe Player est la classe qui s'occupe de gérer le joueur.
    """

    #Création des instances de classe
    max_pv = 3
    speed = 300
    hitbox_rad = 20
    fire_recovery = 0.1
    nom="player"
    vaisceau = pygame.image.load("core/rsc/img/spaceship.png")

################################# CREATION DE LA FONCTION D'INITIALISATION DE LA CLASSE PLAYER AVEC SES ATTRIBUTS ##################################

    #Initialisation de la classe Player et de ses attributs
    def __init__(self,game,position,pv=3):
        self.pos=position
        self.score = 100
        self.pv=pv
        self.game = game
        self.lasershot_sound = pygame.mixer.Sound('core/rsc/sounds/laser_shot.wav')
        self.lasershot_sound.set_volume(0.3)
        self.fire_timer = 0

####################################################################################################################################

################################################## DEFINITION DES METHODES DE LA CLASSE PLAYER #####################################################

    #Méthode de perte de points de vie
    def damage(self):
        self.pv -= 1

    #Méthode de mise à jour du joueur (appelée dans Game)
    def update(self,dt):
        self.fire_timer += dt

    #Méthode de tir
    def shoot(self,dt):
        if self.fire_timer >= self.fire_recovery:
            self.lasershot_sound.play()
            self.game.pl_bullets.append(Bullet([self.pos[0],self.pos[1]-self.hitbox_rad-1],"up"))
            self.fire_timer = 0.0
            self.score -= 1

    # Méthode de la réaction après l'event de clic droit
    def left(self,dt):
        self.pos[0]-=self.speed*dt
        if self.pos[0]<0: self.pos[0]=0

    # Méthode de la réaction après l'event de clic droit
    def right(self,dt):
        self.pos[0]+=self.speed*dt
        if self.pos[0]>550: self.pos[0]=550

    # Méthode de la réaction après l'event de clic droit
    def up(self,dt):
        self.pos[1]-=self.speed*dt
        if self.pos[1]<0: self.pos[1]=0


    # Méthode de la réaction après l'event de clic droit
    def down(self,dt):
        self.pos[1]+=self.speed*dt
        if self.pos[1]>700: self.pos[1]=700

####################################################################################################################################

####################################################################################################################################


