﻿################################################ IMPORTATIONS DES MODULES NECESSAIRES ################################################

from core.game import Game
from core.screen.mainmenu import MainMenuPygameGui as pg

#######################################################################################################################################

#Vérification de la version pygame
def check_pygame_version():
    import pygame.version as p
    import os
    os.system("py -m pip install pygame==1.9.6")

#Lancement du jeu
if __name__ == "__main__":
    check_pygame_version()
    Gui = pg()
    Gui.start()


